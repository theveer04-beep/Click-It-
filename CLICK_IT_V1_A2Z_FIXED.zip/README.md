# CLICK IT — Android APK Project

This is the Android version of the existing CLICK IT Camera v1 prototype.

Features in this build:
- Camera permission and live camera
- Front/back switch
- Flash/torch where supported
- Gallery image picker
- Photo capture
- Retake / Use Click preview
- CLICK IT dark + yellow UI

## Build
Open this project in Android Studio and build the debug APK:
`app/build/outputs/apk/debug/app-debug.apk`

The OpenAI API key is NOT included in this APK. For AI features, use a secure backend and keep the key server-side.
